import os
import json
from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import pickle
import pandas as pd
import numpy as np
from openpyxl import Workbook

########## INITIAL SETUPS ##########
model = pickle.load(open("MultiOutputClassifier.pkl", 'rb'))
####################################

app = Flask(__name__)
CORS(app)

# ----------------------------------#

def makePredictions(X_test):
    predictions = []
    for index, row in X_test.iterrows():
        vals = row.tolist()
        np_array = np.asarray(vals)
        reshaped_array = np_array.reshape(1, -1)
        output = model.predict(reshaped_array).tolist()
        print(output)
        prediction_dict = {
            "Late Delivery": output[0][0],
            "Fraud": output[0][1]
        }
        predictions.append(prediction_dict)
    
    print("\nPredictions: ", predictions)
    
    return predictions

# Modify the predict function in Python
def predict(filePath):
    print("File_path in predict: ", filePath)
    data = pd.read_excel(filePath)
    ####
    data['order date']= pd.to_datetime(data['order date (DateOrders)'])
    data['order year']=data['order date'].dt.year
    data['order month']=data['order date'].dt.month
    data['order day']=data['order date'].dt.day 
    data['order hour']=data['order date'].dt.hour
    data['order minute']=data['order date'].dt.minute

    data = data.loc[:, ['order day','order hour','order minute','Days for shipment (scheduled)', 'Department Name', 'Latitude', 'Longitude', 'Customer Segment', 'Market', 'Order Item Quantity', 'Shipping Mode', 'order_latitude', 'order_longitude']]

    dept_name = {'Apparel': 0, 'Book Shop': 1, 'Discs Shop': 2, 'Fan Shop': 3, 'Fitness': 4, 'Footwear': 5, 'Golf': 6, 'Health and Beauty ': 7, 'Outdoors': 8, 'Pet Shop': 9, 'Technology': 10}
    cus_segment = {'Consumer': 0, 'Corporate': 1, 'Home Office': 2}
    market = {'Africa': 0, 'Europe': 1, 'Latam': 2, 'Pacific Asia': 3, 'Usca': 4}
    ship_mode = {'First Class': 0, 'Same Day': 1, 'Second Class': 2, 'Standard Class': 3}

    dept_name_enc = data['Department Name'].map(dept_name)
    cus_segment_enc = data['Customer Segment'].map(cus_segment)
    market_enc = data['Market'].map(market)
    ship_mode_enc = data['Shipping Mode'].map(ship_mode)

    data['Department Name'] = dept_name_enc
    data['Customer Segment'] = cus_segment_enc
    data['Market'] = market_enc
    data['Shipping Mode'] = ship_mode_enc

    mean = [ 15.63751894,  11.48076272,  29.49129009,   2.9319356 ,
         3.24666337,  29.71645214, -84.90994491,   0.66031066,
         2.10749347,   2.12768248,   2.23485408,  24.79626522,
        -8.48240737]
    
    scale = [ 8.92003574,  6.92365549, 17.31790329,  1.37442119,  2.50296727,
        9.81379964, 21.43387662,  0.76235666,  1.15083771,  1.45350932,
        1.10091429, 24.92893771, 76.46819332]
    
    data = (data-mean)/scale
    ####
    #print(data)
    predictions = makePredictions(data)
    return predictions
    


@app.route('/', methods=['POST'])
def index():
    return app.send_static_file('index.html')

@app.route('/manual_input', methods=['POST'])
def manualInput():
    try:
        vals = request.json
        vals = list(vals.values())
        print(vals)

        columns=['order date (DateOrders)','Days for shipment (scheduled)', 'Department Name', 'Latitude', 'Longitude', 'Customer Segment', 'Market', 'Order Item Quantity', 'Shipping Mode', 'order_latitude', 'order_longitude']

        upload_folder = 'uploads'
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)

        file_path = os.path.join(upload_folder, "singleRow.xlsx")

        workbook = Workbook()
        sheet = workbook.active
        sheet.append(columns)
        sheet.append(vals)
        workbook.save(file_path)

        print(file_path)

        predictions = predict(file_path)
        os.remove(file_path)
        output_json = json.dumps(predictions)
        print("\n\n")
        print(output_json)
        print("\n\n")
        final_response = jsonify(predictions)
        final_response.headers.add('Access-Control-Allow-Origin', '*')
        final_response.headers.add('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE')
        final_response.headers.add('Access-Control-Allow-Methods', 'Content-Type, Authorization')
        return final_response
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/file_input', methods=['POST'])
def remoteDataInput():
    try:
        file = request.files['file']

        # Check if the file is empty
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400

        # Save the file to a specific folder (you can change this path)
        upload_folder = 'uploads'
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)

        file_path = os.path.join(upload_folder, file.filename)
        file.save(file_path)
        print(file_path)
        predictions = predict(file_path)

        output_json = json.dumps(predictions)
        print("\n\n")
        print(output_json)
        print("\n\n")
        final_response = jsonify(predictions)
        final_response.headers.add('Access-Control-Allow-Origin', '*')
        final_response.headers.add('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE')
        final_response.headers.add('Access-Control-Allow-Methods', 'Content-Type, Authorization')
        return final_response

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run()
