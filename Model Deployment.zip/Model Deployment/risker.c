#include <stdlib.h>

int main() {

    system("start C:/Users/Vaibh/Downloads/SMLFinalProject/main_UI.html"); 
 
    system("python C:/Users/Vaibh/Downloads/SMLFinalProject/SML_BackEnd.py");  

    return 0;
}