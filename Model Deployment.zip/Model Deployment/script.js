$(document).ready(function() {

    $('#submitBtn').click(function() {
        var inputValues = {
          orderDate: $('#orderDate').val(),
          daysForShipment: $('#daysForShipment').val(),
          departmentName: $('#departmentName').val(),
          latitude: $('#latitude').val(),
          longitude: $('#longitude').val(),
          customerSegment: $('#customerSegment').val(),
          market: $('#market').val(),
          orderItemQuantity: $('#orderItemQuantity').val(),
          shippingMode: $('#shippingMode').val(),
          orderLatitude: $('#orderLatitude').val(),
          orderLongitude: $('#orderLongitude').val()
        };
    
        sendManualInputToServer(inputValues);
        
      });
    
      function validateInput(inputValues) {
        // Minimal validation example, add more checks as needed
        for (var key in inputValues) {
          if (inputValues.hasOwnProperty(key)) {
            var value = inputValues[key];
            if (value === '' || isNaN(value)) {
              return false;
            }
          }
        }
        return true;
      }
    
      function sendManualInputToServer(inputValues) {
        $.ajax({
          url: 'http://localhost:5000/manual_input',
          type: 'POST',
          data: JSON.stringify(inputValues),
          contentType: 'application/json',
          success: function(response) {
            console.log(response);
            displayOutput(response);
          },
          error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText;
            alert('Error - ' + errorMessage);
          }
        });
      }
      
    $('#fileInput').change(function(event) {
      var fileInput = event.target;
      var file = fileInput.files[0];
  
      if (file) {
        sendFileToServer(file);
      }
    });
  
    function sendFileToServer(file) {
      var formData = new FormData();
      formData.append('file', file);
  
      $.ajax({
        url: 'http://localhost:5000/file_input',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function(response) {
          console.log(response);
          displayOutput(response);
        },
  
        error: function(xhr, status, error) {
          var errorMessage = xhr.status + ': ' + xhr.statusText;
          alert('Error - ' + errorMessage);
        }
      });
    }
  
    function displayOutput(predictions) {
      var outputContainer = $('#outputContainer');
      outputContainer.empty();
  
      // Create a table
      var table = $('<table>').addClass('table');
      var thead = $('<thead>').appendTo(table);
      var tbody = $('<tbody>').appendTo(table);
  
      // Create table headers
      var headers = Object.keys(predictions[0]);
      var headerRow = $('<tr>').appendTo(thead);
      headerRow.append($('<th>').text('Serial Number'));
      headers.forEach(function(header) {
        headerRow.append($('<th>').text(header));
      });
  
      // Create table rows
      predictions.forEach(function(prediction, index) {
        var row = $('<tr>').appendTo(tbody);
        row.append($('<td>').text(index + 1)); // Serial number
  
        headers.forEach(function(header) {
            var cell = $('<td>').text(prediction[header] == 0 ? 'No risk' : 'Suspected risk');
            cell.addClass(prediction[header] == 0 ? 'no-risk' : 'suspected-risk');
            row.append(cell);
          });
        });
  
      // Append the table to the output container
      outputContainer.append(table);
    }
  });
  